#######################
# Paquetes necesarios #
#######################
import os
import time
import getpass
import random as rdm
from datetime import datetime
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = "hide" # Ocultar el mensaje de bienvenida de pygame
# Manejo de errores por librerías no instaladas
try:
    import openpyxl
    import pandas as pd
    import pygame
except ModuleNotFoundError as e:
    print("⚠️ Falta una librería necesaria:", e.name)
    print("Instala las dependencias con: pip install -r requirements.txt")


################
# Validaciones #
################


# Validar opción y/o dificultad
def valida(minimo, maximo):
    mensaje = f"Elige una opción entre {minimo} y {maximo}: "
    while True: #bucle infinito hasta que se introduzca una opción válida
        try:
            opcion = int(input(mensaje))
            if minimo <= opcion <= maximo:
                return opcion
            else:
                mensaje = f"⚠️ Opción no válida. Debe estar entre {minimo} y {maximo}: " # Cuando el número no está en el rango
        except ValueError:
            mensaje = f"🚫 Valor no válido. Introduce un número entre {minimo} y {maximo}: " # Cuando no se introduce un número

# Validar número introducido (igual que la validación de opción)
def valida_numero(nombre_jugador):
    # Establecemos el mínimo y el máximo
    minimo = 1 
    maximo = 1000
    mensaje = f"{nombre_jugador}, adivina el número entre {minimo} y {maximo}: "
    while True:
        try:
            numero = int(input(mensaje))
            if minimo <= numero <= maximo:
                return numero
            else:
                mensaje = f"⚠️ Número no válido. Debe estar entre {minimo} y {maximo}: "
        except ValueError:
            mensaje = f"🚫 Valor no válido. Introduce un número entre {minimo} y {maximo}: "

# Validar el número oculto introducido (igual que las dos validaciones anteriores)
def valida_numero_oculto(nombre_jugador):
    minimo = 1
    maximo = 1000
    mensaje = f"{nombre_jugador}, introduce el número a adivinar (entre {minimo} y {maximo}): "
    while True:
        try:
            numero = int(getpass.getpass(mensaje))
            if minimo <= numero <= maximo:
                return numero
            else:
                mensaje = f"⚠️ Número no válido. Debe estar entre {minimo} y {maximo}: "
        except ValueError:
            mensaje = f"🚫 Valor no válido. Introduce un número entre {minimo} y {maximo}: "


#######################
# Funciones de sonido #
#######################


# Los sonidos deben estar en la misma carpeta que el script

# Música de fondo
def musica_fondo():
    ruta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "game_music.mp3")
    pygame.mixer.music.stop()
    pygame.mixer.music.load(ruta)
    pygame.mixer.music.play(-1) # Reproducir en bucle

# Música de fondo según dificultad
def musica_fondo_facil():
    ruta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "easy_mode_music.mp3")
    pygame.mixer.music.stop()
    pygame.mixer.music.load(ruta)
    pygame.mixer.music.play(-1)

def musica_fondo_medio():
    ruta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "medium_mode_music.mp3")
    pygame.mixer.music.stop()
    pygame.mixer.music.load(ruta)
    pygame.mixer.music.play(-1)

def musica_fondo_dificil():
    ruta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "hard_mode_music.mp3")
    pygame.mixer.music.stop()
    pygame.mixer.music.load(ruta)
    pygame.mixer.music.play(-1)

# Sonido de victoria al adivinar el número
def sonido_victoria():
    ruta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "victory_sound.mp3")
    sonido = pygame.mixer.Sound(ruta)
    sonido.play()

# Sonido de derrota al no adivinar el número
def sonido_derrota():
    ruta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "defeat_sound.mp3")
    sonido = pygame.mixer.Sound(ruta)
    sonido.play()


###################################
# Funciones principales del juego #
###################################


# ¡A jugar!
def jugar():
    pygame.mixer.init()
    musica_fondo()
    menu()

# Menú principal del juego
def menu():
    print("\n🎯==============================🎯")
    print("       ¡ADIVINA EL NÚMERO! 🎲")
    print("🎯==============================🎯\n")
    print("1️⃣  Modo Solitario")
    print("   🤖 Ponte a prueba contra el ordenador. ¡Demuestra lo que vales!")
    print("\n2️⃣  Modo Multijugador")
    print("   👥 Un jugador elige el número, el otro intenta adivinarlo.")
    print("\n3️⃣  Estadísticas")
    print("   📊 Consulta tus logros y puntuaciones guardadas.")
    print("\n4️⃣  Salir")
    print("   🚪 Cierra el juego.\n")
    opcion = valida(1, 4)
    if opcion == 1:
        modo_solitario()
    elif opcion == 2:
        modo_multijugador()
    elif opcion == 3:
        estadistica()
    else:
        salir()
    return

# Salir del juego (con animación)
def salir():
    print("👋 ¡Hasta luego!")
    print("\nSaliendo", end="", flush=True)
    for _ in range(3):
        time.sleep(0.4)
        print(".", end="", flush=True)
    time.sleep(0.5)
    print("✨ Has salido del juego. ¡Vuelve pronto! 🎯\n")
    pygame.mixer.quit()
    return

# Menu de dificultad
def submenu():
    print("\n==================================")
    print("💪 ELIGE TU NIVEL DE DIFICULTAD 💪")
    print("==================================\n")
    print("🐣 1️⃣  Fácil — 20 intentos")
    print("   🌼 Ideal para calentar motores y disfrutar sin prisas.\n")
    print("🔥 2️⃣  Medio — 12 intentos")
    print("   ⚡ Un desafío equilibrado: ¡demuestra tu instinto!\n")
    print("💀 3️⃣  Difícil — 5 intentos")
    print("   💣 Solo para valientes. ¿Te atreves?\n")
    print("↩️ 4️⃣  Volver al menú principal")
    print("   🔙 ¿Cambiaste de idea?, ¡no pasa nada!\n")
    dificultad = valida(1, 4)
    if dificultad == 1:
        musica_fondo_facil()
        return 20
    elif dificultad == 2:
        musica_fondo_medio()
        return 12
    elif dificultad == 3:
        musica_fondo_dificil()
        return 5
    else:
        print("\nVolviendo", end="", flush=True)
        for _ in range(3):
            time.sleep(0.4)
            print(".", end="", flush=True)
        time.sleep(0.5)
        print("\n")
        jugar()  # Volver al menú principal si la opción no es válida

# Modo solitario
def modo_solitario():
    # Establecer número de intentos según dificultad
    intentos = submenu()
    if intentos is None: # Volver al menú principal si no hay intentos guardados (opción 4)
        return
    # Datos que se van a guardar
    modo = "Solitario"
    numero_a_adivinar = rdm.randint(1, 1000)
    nombre_jugador = input("Introduce tu nombre para guardar tu progreso: ")
    estadisticas_jugador = []
    
    # Frases aleatorias para pistas
    pistas_mayor = [
        "\n🔺 ¡Más arriba, más arriba!\n",
        "\n📈 Sube un poco más, ¡casi llegas!\n",
        "\n😏 El número es más grande...\n",
        "\n🚀 Necesitas apuntar más alto.\n",
        "\n🧗‍♂️ Piensa en algo más grande.\n"
    ]

    pistas_menor = [
        "\n🔻 ¡Demasiado alto, bájale un poco!\n",
        "\n📉 Ups, te pasaste. Prueba un número menor.\n",
        "\n😅 No tan alto, intenta más bajo.\n",
        "\n🏂 Baja un poco, que te pasaste.\n",
        "\n🐜 El número es más pequeño que este.\n"
    ]

    # Bucle de intentos para adivinar el número
    for i in range(intentos):
        numero_introducido = valida_numero(nombre_jugador)
        if numero_introducido < numero_a_adivinar:
            print(rdm.choice(pistas_mayor))
        elif numero_introducido > numero_a_adivinar:
            print(rdm.choice(pistas_menor))
        else:
            print(f"\n🎉 ¡Has adivinado el número en {i+1} intentos!\n")
            print(f"\n😄¡Sí señor! Era {numero_a_adivinar}. ¡Qué puntería tienes {nombre_jugador}!\n")
            sonido_victoria()
            resultado = "Victoria"
            fecha_hora_actual = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            estadisticas_jugador.append((modo, nombre_jugador, numero_a_adivinar, i+1, resultado, fecha_hora_actual))
            guardar_stats(estadisticas_jugador)
            jugar()
            return
    else:
        print(f"\n😢 Se acabaron los intentos. El número era {numero_a_adivinar}. Pero oye, la intención es lo que cuenta... 😏\n")
        print(f"\n💪 ¡No te rindas {nombre_jugador}! La próxima vez seguro lo consigues.\n")
        sonido_derrota()
        resultado = "Derrota"
        fecha_hora_actual = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        estadisticas_jugador.append((modo, nombre_jugador, numero_a_adivinar, i+1, resultado, fecha_hora_actual))
        guardar_stats(estadisticas_jugador)
        jugar()
        return
    
# Modo multijugador
def modo_multijugador():
    # Establecer número de intentos según dificultad
    intentos = submenu()
    if intentos is None: # Volver al menú principal si no hay intentos guardados (opción 4)
        return
    # Datos que se van a guardar
    modo = "Multijugador"
    nombre_jugador1 = input("Jugador 1, introduce tu nombre: ")
    nombre_jugador2 = input("Jugador 2, introduce tu nombre: ")
    numero_a_adivinar_jugador1 = valida_numero_oculto(nombre_jugador1)
    estadisticas_jugador = [] 

    # Frases aleatorias para pistas
    pistas_mayor = [
        "\n🔺 ¡Más arriba, más arriba!\n",
        "\n📈 Sube un poco más, ¡casi llegas!\n",
        "\n😏 El número es más grande...\n",
        "\n🚀 Necesitas apuntar más alto.\n",
        "\n🧗‍♂️ Piensa en algo más grande.\n"
    ]

    pistas_menor = [
        "\n🔻 ¡Demasiado alto, bájale un poco!\n",
        "\n📉 Ups, te pasaste. Prueba un número menor.\n",
        "\n😅 No tan alto, intenta más bajo.\n",
        "\n🏂 Baja un poco, que te pasaste.\n",
        "\n🐜 El número es más pequeño que ese.\n"
    ]

    # Bucle de intentos para adivinar el número
    for i in range(intentos):
        numero_introducido_jugador2 = valida_numero(nombre_jugador2)
        if numero_introducido_jugador2 < numero_a_adivinar_jugador1:
            print(rdm.choice(pistas_mayor))
        elif numero_introducido_jugador2 > numero_a_adivinar_jugador1:
            print(rdm.choice(pistas_menor))
        else:
            print(f"\n🎉 ¡Has adivinado el número en {i+1} intentos!\n")
            print(f"\n😄 ¡Sí señor! Era {numero_a_adivinar_jugador1}. ¡{nombre_jugador1} no ha podido contigo, {nombre_jugador2}!\n")
            sonido_victoria()
            resultado = "Victoria"
            fecha_hora_actual = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            estadisticas_jugador.append((modo, nombre_jugador2, numero_a_adivinar_jugador1, i+1, resultado, fecha_hora_actual))
            guardar_stats(estadisticas_jugador)
            jugar()
            return
    else:
        print(f"\n😢 Se acabaron los intentos. El número era {numero_a_adivinar_jugador1}. Pero oye, la intención es lo que cuenta... 😏\n")
        print(f"\n💪 ¡Vaya número te ha puesto {nombre_jugador1}! La próxima vez seguro lo consigues {nombre_jugador2}.\n")
        sonido_derrota()
        resultado = "Derrota"
        fecha_hora_actual = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        estadisticas_jugador.append((modo, nombre_jugador2, numero_a_adivinar_jugador1, i+1, resultado, fecha_hora_actual))
        guardar_stats(estadisticas_jugador)
        jugar()
        return  
    
# Guardar estadísticas
def guardar_stats(estadisticas_jugador):
    bbdd_guessthenumber_act = pd.DataFrame(estadisticas_jugador, columns=["Modo", "Nombre", "Número a adivinar", "Intentos", "Resultado", "Fecha y hora"])
    # Comprobar si el archivo ya existe para añadir los nuevos datos
    if os.path.exists("estadisticas_jugador.xlsx"):
        bbdd_guessthenumber_ant = pd.read_excel("estadisticas_jugador.xlsx")
        bbdd_guessthenumber = pd.concat([bbdd_guessthenumber_ant, bbdd_guessthenumber_act], ignore_index=True)
    # Si no existe, crear uno nuevo
    else:
        bbdd_guessthenumber = bbdd_guessthenumber_act
    bbdd_guessthenumber.to_excel("estadisticas_jugador.xlsx", index=False)
    return

# Estadísticas
def estadistica():
    print("\nCargando", end="", flush=True)
    for _ in range(3):
        time.sleep(0.4)
        print(".", end="", flush=True)
    time.sleep(0.5)
    print("\n")
    # Comprobar si el archivo de estadísticas existe
    if os.path.exists("estadisticas_jugador.xlsx"):
        bbdd_guessthenumber = pd.read_excel("estadisticas_jugador.xlsx")
        texto = "📊 ESTADÍSTICAS DE JUEGO 📊"
        print(texto.center(90))
        print("=" * 90)
        print(bbdd_guessthenumber.to_string(index=False))
        print("=" * 90 + "\n")
        jugar()
        return
    # Si no existe, informar al jugador
    else:
        print("No hay estadísticas guardadas.")
        jugar()
        return